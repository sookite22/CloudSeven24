const { createVote, getVote, getResults, submitVote, getAllVotes } = require('./function/votes');

exports.handler = async (event) => {
    const { path, httpMethod, body } = event;

    try {
        const parsedBody = body ? JSON.parse(body) : {};

        if (httpMethod === 'GET' && path === '/votes') {
            return await getAllVotes();
        }
        if (httpMethod === 'POST' && path === '/votes') {
            return await createVote(parsedBody);
        }
        if (httpMethod === 'GET' && path.startsWith('/vote/')) {
            const voteId = path.split('/')[2];
            return await getVote(voteId);
        }
        if (httpMethod === 'POST' && path.startsWith('/vote/')) {
            const voteId = path.split('/')[2];
            return await submitVote(voteId, parsedBody);
        }
        if (httpMethod === 'GET' && path.startsWith('/results/')) {
            const voteId = path.split('/')[2];
            return await getResults(voteId);
        }

        return { statusCode: 404, body: JSON.stringify({ message: 'Route not found' }) };
    } catch (error) {
        console.error('Error handling request:', error);
        return { statusCode: 500, body: JSON.stringify({ message: 'Internal server error' }) };
    }
};
